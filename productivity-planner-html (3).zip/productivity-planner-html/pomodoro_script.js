/*defining the work and rest minutes, and getting the timer elements from the HTML*/
let workMins = 25;
let restMins = 5;

let mode = "work";
let pomodoroCount = 0;
let time = workMins * 60;

const Timer = document.getElementById("timer");
const startButton = document.getElementById("start");
const modeText = document.getElementById("mode");

let intervalId = null;

/*setting the time variable to the number of seconds in the work minutes, and starting the timer to update every second*/

startButton.addEventListener("click", startTimer);

function startTimer() {
    if (intervalId === null) {
        intervalId = setInterval(updateTimer, 1000);
    }
}


/*function to update the work timer, calculating the minutes and seconds from the time variable, and updating the HTML elements accordingly*/
function updateTimer() {
    

    
    
    console.log("mode:", mode);
    console.log("time:", time);
    console.log("count:", pomodoroCount);
    if (time <= 0) {
        
        if (mode === "work") {

            pomodoroCount++;

            if (pomodoroCount === 4) {
                clearInterval(intervalId);
                intervalId = null;

                alert("Pomodoro cycle complete!");
                return;
            }
            else {
                alert("Time's up! Take a break.");
                mode = "rest";
                modeText.textContent = "Break Time";
                time = restMins * 60;
            }
        } 
        else {
            alert("Time's up! Get back to work.");
            mode = "work";
            modeText.textContent = "Work Session";
            time = workMins * 60;
        }
        return;
    }
    
    const mins = Math.floor(time / 60);
    const secs = time % 60;

    Timer.innerHTML = `${mins}:${secs < 10 ? "0" + secs : secs}`;

    time--;
}
