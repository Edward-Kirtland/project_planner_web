const daySelect = document.getElementById("days")
const eventInput = document.getElementById("event_content")
const saveButton = document.getElementById("save_event")

let timetable = JSON.parse(localStorage.getItem("timetable")) || {};

displayEvents();

saveButton.addEventListener("click", saveEvent);

function saveEvent() {
    console.log("Save clicked");
    
    const day = daySelect.value;
    const eventText = eventInput.value.trim();

    if (eventText === "") return;

    if (!timetable[day]) {
        timetable[day] = [];
    }

    timetable[day].push(eventText);

    localStorage.setItem("timetable", JSON.stringify(timetable));

    displayEvents();

    eventInput.value = "";
}

function displayEvents() {
    const days = [
        "sunday",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday"
    ];

    days.forEach(day => {
        const cell = document.getElementById(`${day}_text`);

        if (!timetable[day] || timetable[day].length === 0) {
            cell.innerHTML = "";
            return;
        }

        cell.innerHTML = timetable[day]
            .map((event, index) => `
                <div class="event"
                    onclick="deleteEvent('${day}', ${index})">
                    ${event}
                </div>
        `)
        .join("");
    });
}

function deleteEvent(day, index) {
    timetable[day].splice(index, 1);

    localStorage.setItem(
        "timetable",
        JSON.stringify(timetable)
    );

    displayEvents();
}