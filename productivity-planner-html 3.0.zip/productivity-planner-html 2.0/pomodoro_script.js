/*defining the mode, count, work and rest minutes, and getting the timer elements from the HTML*/
let workMins = 25;
let restMins = 5;

let mode = "work";
let pomodoroCount = 0;
let time = workMins * 60;

const Timer = document.getElementById("timer");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const resetButton = document.getElementById("reset");
const modeText = document.getElementById("mode");

let intervalId = null;

/*setting up event listeners for the timer buttons*/

startButton.addEventListener("click", startTimer);
pauseButton.addEventListener("click", pauseTimer);
resetButton.addEventListener("click", resetTimer);


/*function to start the timer and prevent multiple clicks from causing issues*/
function startTimer() {
    if (intervalId === null) {
        intervalId = setInterval(updateTimer, 1000);
    }
}
/*function to pause the timer*/
function pauseTimer() {
    if (intervalId !== null) {
        clearInterval(intervalId);
        intervalId = null;
    }
}
/*function to reset the timer and pomodoro count*/
function resetTimer() {
    clearInterval(intervalId);
    intervalId = null;
    mode = "work";
    pomodoroCount = 0;
    time = workMins * 60;
    Timer.innerHTML = `${workMins}:00`;
    modeText.textContent = "Work Session";
}

/*function to update the work timer, calculating the minutes and seconds from the time variable,
and updating the HTML elements accordingly*/
function updateTimer() {  
    console.log("mode:", mode);
    console.log("time:", time);
    console.log("count:", pomodoroCount);
    if (time <= 0) {
        
        if (mode === "work") {

            pomodoroCount++;

            if (pomodoroCount === 4) {
                clearInterval(intervalId);
                intervalId = null;

                alert("Pomodoro cycle complete!");
                return;
            }
            else {
                alert("Time's up! Take a break.");
                mode = "rest";
                modeText.textContent = "Break Time";
                time = restMins * 60;
            }
        } 
        else {
            alert("Time's up! Get back to work.");
            mode = "work";
            modeText.textContent = "Work Session";
            time = workMins * 60;
        }
        return;
    }
    
    const mins = Math.floor(time / 60);
    const secs = time % 60;

    Timer.innerHTML = `${mins}:${secs < 10 ? "0" + secs : secs}`;

    time--;
}
