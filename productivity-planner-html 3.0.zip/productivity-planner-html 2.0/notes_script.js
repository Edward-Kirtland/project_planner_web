/* Get references to the HTML elements the user interacts with*/
let inputTitle = document.getElementById("note_title");
let saveButton = document.getElementById("save_note");
let inputText = document.getElementById("note_content");
let output = document.getElementById("saved_notes");


/*Get previously saved notes from local storage, if no notes exist create an empty array*/
let notes = JSON.parse(localStorage.getItem("notes")) || [];


/*Display all notes stored in the array*/
function displayNotes() {
    /*Clear output before drawing notes*/
    output.innerHTML = "";
    /*Loop to draw all notes in the array*/
    notes.forEach((note, index) => {
        const noteCard = document.createElement("div");
        noteCard.classList.add("saved-note");
        /*Format for note card*/
        noteCard.innerHTML = `
            <button class="delete-note" data-index="${index}">✕</button>
            <h3>${note.title}</h3>
            <p>${note.content}</p>
        `;
        
        /*Add note to notes section*/
        output.appendChild(noteCard);

})
    /*Reference to delete element in HTML*/
    const deleteButtons = document.querySelectorAll(".delete-note");
    /*Click functionality for delete button*/
    deleteButtons.forEach(button => {

        button.addEventListener("click", function (){
            /*Get notes position in the array*/
            const index = this.dataset.index;
            /*Remove selected note*/
            notes.splice(index, 1);
            /*Update local storage*/
            localStorage.setItem("notes", JSON.stringify(notes));
            /*Refresh notes page*/
            displayNotes();

        })
    })


}
/*Click functionality for save button*/
saveButton.addEventListener("click", () => {
    /*Limit saved notes to 6*/
    if (notes.length >= 6) {
        alert("You can only save 6 notes.");
        return;
    }
    /*Trim unnecessary spaces from user input*/
    const title = inputTitle.value.trim();
    const content = inputText.value.trim();

    /*Stop empty notes from being saved*/
    if (title === "" || content === "") {
        alert("Please enter a title and note");
        return;
    }

    /*Note object*/
    const note = {
        title: title,
        content: content
    };
    /*Add note to array*/
    notes.push(note);
    /*Save updated array to local storage*/
    localStorage.setItem("notes", JSON.stringify(notes));
    /*Prepare input boxes for new note*/
    inputTitle.value = "";
    inputText.value = "";
    /*Refresh displayed notes*/
    displayNotes();
})
/*Display notes from local storage when page is loaded*/
displayNotes();

