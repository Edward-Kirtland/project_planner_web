/* Get references to the HTML elements the user interacts with*/
const daySelect = document.getElementById("days")
const eventInput = document.getElementById("event_content")
const saveButton = document.getElementById("save_event")

/* Load timetable from localStorage or initialise empty object */
let timetable = JSON.parse(localStorage.getItem("timetable")) || {};

/* Render stored events on page load */
displayEvents();

/* Handle save button click */
saveButton.addEventListener("click", saveEvent);

/* Save a new event to the selected day */
function saveEvent() {
    console.log("Save clicked");
    
    const day = daySelect.value;
    const eventText = eventInput.value.trim();

    /* Prevent empty events */
    if (eventText === "") return;

    /* Create array for day if it does not exist */
    if (!timetable[day]) {
        timetable[day] = [];
    }

    /* Add event to selected day */
    timetable[day].push(eventText);

    /* Save updated timetable to localStorage */
    localStorage.setItem("timetable", JSON.stringify(timetable));

    /* Refresh displayed events */
    displayEvents();

    /* Clear input field */
    eventInput.value = "";
}

/* Display all events in the weekly table */
function displayEvents() {
    const days = [
        "sunday",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday"
    ];

    days.forEach(day => {
        const cell = document.getElementById(`${day}_text`);

        /* Clear cell if no events exist */
        if (!timetable[day] || timetable[day].length === 0) {
            cell.innerHTML = "";
            return;
        }

        /* Render events for each day */
        cell.innerHTML = timetable[day]
            .map((event, index) => `
                <div class="event"
                    onclick="deleteEvent('${day}', ${index})">
                    ${event}
                </div>
            `)
        .join("");
    });
}

/* Delete a specific event from a day */
function deleteEvent(day, index) {
    timetable[day].splice(index, 1);

    /* Update localStorage after deletion */
    localStorage.setItem(
        "timetable",
        JSON.stringify(timetable)
    );

    /* Refresh UI */
    displayEvents();
}