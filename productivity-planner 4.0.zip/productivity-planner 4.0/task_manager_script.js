﻿/* Get references to the HTML elements the user interacts with*/
const taskContent = document.getElementById("task_content");
const saveTaskButton = document.getElementById("save_task");
const prioritySelect = document.getElementById("priority");
const taskOutput = document.getElementById("saved_task");

/* Load existing tasks from localStorage or initialise empty array */
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

/* Render tasks to the page and apply sorting and delete handlers */
function displayTasks() {
    taskOutput.innerHTML = "";

    /* Define priority ranking for sorting */
    const priorityOrder = {
        High: 1,
        Medium: 2,
        Low: 3
    };

    /* Sort tasks by priority before displaying */
    tasks.sort((a, b) => {
        return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    /* Save sorted tasks back to localStorage */
    localStorage.setItem("tasks", JSON.stringify(tasks));

    /* Create and display each task card */
    tasks.forEach((task, index) => {
        const taskCard = document.createElement("div");
        taskCard.classList.add("saved-task");

        taskCard.innerHTML = `
            <button class="delete-task" data-index="${index}">✕</button>
            <h3>${task.priority}</h3>
            <p>${task.content}</p>
        `;

        taskOutput.appendChild(taskCard);
    });

    /* Attach delete functionality to each task */
    const deleteButtons = document.querySelectorAll(".delete-task");
    deleteButtons.forEach(button => {
        button.addEventListener("click", function () {
            const index = this.dataset.index;
            tasks.splice(index, 1);
            localStorage.setItem("tasks", JSON.stringify(tasks));
            displayTasks();
        });
    });
}

/* Handle saving a new task */
saveTaskButton.addEventListener("click", () => {

    /* Limit number of stored tasks */
    if (tasks.length >= 6) {
        alert("You can only save 6 tasks.");
        return;
    }

    const content = taskContent.value.trim();
    const priority = prioritySelect.value;

    /* Prevent empty task submission */
    if (content === "") {
        alert("Please enter a task.");
        return;
    }

    /* Create task object with formatted priority */
    const task = {
        priority: priority.charAt(0).toUpperCase() + priority.slice(1),
        content
    };

    /* Add task to array and save to localStorage */
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));

    /* Reset input fields */
    taskContent.value = "";
    prioritySelect.value = "high";

    /* Refresh displayed tasks */
    displayTasks();
});

/* Initial render on page load */
displayTasks();