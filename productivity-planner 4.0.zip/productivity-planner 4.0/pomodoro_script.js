/* Define timer settings, mode state, and initial values */
let workMins = 25;
let restMins = 5;

/* Track current session type and completed pomodoros */
let mode = "work";
let pomodoroCount = 0;

/* Convert work time into seconds for countdown logic */
let time = workMins * 60;

/* Get timer-related elements from the HTML */
const Timer = document.getElementById("timer");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const resetButton = document.getElementById("reset");
const modeText = document.getElementById("mode");

/* Store interval ID for start/pause control */
let intervalId = null;

/* Event listeners for timer controls */
startButton.addEventListener("click", startTimer);
pauseButton.addEventListener("click", pauseTimer);
resetButton.addEventListener("click", resetTimer);

/* Start the timer if it is not already running */
function startTimer() {
    if (intervalId === null) {
        intervalId = setInterval(updateTimer, 1000);
    }
}

/* Pause the timer */
function pauseTimer() {
    if (intervalId !== null) {
        clearInterval(intervalId);
        intervalId = null;
    }
}

/* Reset timer and session state */
function resetTimer() {
    clearInterval(intervalId);
    intervalId = null;

    mode = "work";
    pomodoroCount = 0;
    time = workMins * 60;

    Timer.innerHTML = `${workMins}:00`;
    modeText.textContent = "Work Session";
}

/* Update timer every second and handle mode switching */
function updateTimer() {  
    console.log("mode:", mode);
    console.log("time:", time);
    console.log("count:", pomodoroCount);

    if (time <= 0) {

        if (mode === "work") {

            pomodoroCount++;

            if (pomodoroCount === 4) {
                clearInterval(intervalId);
                intervalId = null;

                alert("Pomodoro cycle complete!");
                return;
            }
            else {
                alert("Time's up! Take a break.");
                mode = "rest";
                modeText.textContent = "Break Time";
                time = restMins * 60;
            }
        } 
        else {
            alert("Time's up! Get back to work.");
            mode = "work";
            modeText.textContent = "Work Session";
            time = workMins * 60;
        }
        return;
    }

    /* Calculate minutes and seconds from remaining time */
    const mins = Math.floor(time / 60);
    const secs = time % 60;

    /* Update timer display */
    Timer.innerHTML = `${mins}:${secs < 10 ? "0" + secs : secs}`;

    time--;
}